//
//  StartView.swift
//  MUSC-Anesthesia WatchKit Extension
//
//  Created by Nicolas Threatt on 7/25/18.
//  Copyright © 2018 Riggs Lab. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

var start = 0
var timeHit: Bool = false


extension String  {
    var isNumber: Bool {
        return !isEmpty && rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
}

class StartView: WKInterfaceController ,WCSessionDelegate{
    
    weak var timer: Timer?
    let calendar = Calendar.current
    var recievedMin: String?

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        //
    }
    
    var session:WCSession!
    /* NOT needed 
    @IBAction func sendMessageToWatch() {
        if(WCSession.isSupported()){
            session.sendMessage(["b":"goodbye"], replyHandler: nil, errorHandler: nil)
        }
    }*/
    //recieveing message from iphone
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        recievedMin = message["a"]! as? String
        self.messageLabel.setText(message["a"]! as? String)
        
    }
    @IBOutlet var messageLabel: WKInterfaceLabel!
    @IBOutlet var pickerView: WKInterfacePicker!
    @IBOutlet var StartingInLabel: WKInterfaceLabel!
    
    let inputFiles = ["File 1", "File 2", "File 3"]

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        
        if let vcID = self.value(forKey: "_viewControllerID") as? NSString {
            print("Page One: \(vcID)")
        }
        
        
        //for sharing
        if(WCSession.isSupported()){
            self.session = WCSession.default
            self.session.delegate = self
            self.session.activate()
            
        }
        
        let pickerItems: [WKPickerItem] = inputFiles.map { file in
            let item = WKPickerItem()
            item.title = file
            item.caption = file

            return item
        }
        pickerView.setItems(pickerItems)
    }
    
    @IBAction func pickerSelectedItemChanged(_ value: Int) {
        fileRecieve = inputFiles[value]
    }
    
    @IBAction func Start() {
        start = 1
        print("Start")
    }
    @IBAction func startButton() {
        
        timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        //sleep(4)
        //presentController(withName: "secondpage", context: nil)
        print ("startButton")

    }
    
    @objc func updateCounter() {
        
        
        if let myInt = Int(recievedMin ?? "Hi"){
            var timeUntilStart = 1;
            
            if(calendar.component(.minute, from: Date()) < myInt){
                timeUntilStart = myInt - calendar.component(.minute, from: Date())
            }
            else{
                timeUntilStart = (60 - calendar.component(.minute, from: Date())) + myInt;
            }
            
            StartingInLabel.setText("Starting in : \(timeUntilStart) mins")
            
            if(calendar.component(.minute, from: Date()) == myInt && timeHit == false){
                timeHit = true;
                print("secondPageNow")
                presentController(withName: "secondpage", context: nil)
            }
            
        } else{
            print("DontStartYet");
    
        }
    }
}
