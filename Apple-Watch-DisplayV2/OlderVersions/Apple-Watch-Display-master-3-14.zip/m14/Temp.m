//
//  Temp.m
//  MUSC-Anesthesia-djobrie
//
//  Created by Daniel  on 3/1/19.
//  Copyright © 2019 Riggs Lab. All rights reserved.
//

#import "Temp.h"

@implementation Temp

@end
