//
//  StartView.swift
//  MUSC-Anesthesia WatchKit Extension
//
//  Created by Nicolas Threatt on 7/25/18.
//  Copyright © 2018 Riggs Lab. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

var start = 0

class StartView: WKInterfaceController ,WCSessionDelegate{
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        //
    }
    
    var session:WCSession!
    
    @IBAction func sendMessageToWatch() {
        if(WCSession.isSupported()){
            session.sendMessage(["b":"goodbye"], replyHandler: nil, errorHandler: nil)
        }
        
    }
    //recieveing message from iphone
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        self.messageLabel.setText(message["a"]! as? String)
    }
    @IBOutlet var messageLabel: WKInterfaceLabel!
    @IBOutlet var pickerView: WKInterfacePicker!
    
    let inputFiles = ["File 1", "File 2", "File 3"]

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        //for sharing
        if(WCSession.isSupported()){
            self.session = WCSession.default
            self.session.delegate = self
            self.session.activate()
            
        }
        
        let pickerItems: [WKPickerItem] = inputFiles.map { file in
            let item = WKPickerItem()
            item.title = file
            item.caption = file

            return item
        }
        pickerView.setItems(pickerItems)
    }
    
    @IBAction func pickerSelectedItemChanged(_ value: Int) {
        fileRecieve = inputFiles[value]
    }
    
    @IBAction func Start() {
        start = 1

    }
    @IBAction func startButton() {
        sleep(4)
        presentController(withName: "secondpage", context: nil)

    }
}
