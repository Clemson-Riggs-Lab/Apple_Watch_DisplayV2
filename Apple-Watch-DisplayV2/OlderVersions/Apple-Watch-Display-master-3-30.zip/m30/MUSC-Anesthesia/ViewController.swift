//
//  ViewController.swift
//  MUSC-Anesthesia
//
//  Created by Nicolas Threatt on 6/19/18.
//  Copyright © 2018 Riggs Lab. All rights reserved.
//

import UIKit
import WatchConnectivity

extension Date {
    var millisecondsSince1970:Int64 {
        return Int64((self.timeIntervalSince1970 * 1000.0).rounded())
        //RESOLVED CRASH HERE
    }
    init(milliseconds:Int64) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds / 1000))
    }
}
//this is for the time selector
extension UIToolbar {
    
    func ToolbarPiker(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([ spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        return toolBar
    }
    
}


//class ViewController: UIViewController {
class ViewController: UIViewController, WCSessionDelegate {
    var session: WCSession!
    
    @IBAction func dateButton(_ sender: Any) {
        self.dateText.text = "\(Date(milliseconds: 0))"
        start()
    }
    
    @IBOutlet weak var dateText: UILabel!
    
    @IBOutlet weak var messageLabel: UILabel!
    
    @IBOutlet weak var inputTimeField: UITextField!
    private var datePicker: UIDatePicker?
    
    @IBOutlet weak var labelMinute: UILabel!
    
    @IBOutlet weak var labelSecond: UILabel!
    @IBOutlet weak var labelMillisecond: UILabel!
    
    weak var timer: Timer?
    
    var startTime: Double = 0
    var time: Double = 0
    var elapsed: Double = 0
    var status: Bool = false
    var goTime: Double = 0
    
    let date = Date()
    let expirationDate = Date()
    var components = DateComponents()
    let calendar = Calendar.current
    
    var sendString: String = ""
    var sendHour: Int = 0
    var sendMin: Int = 0
    
    
    
    @objc func updateCounter() {
        /*
        // Calculate total time since timer started in seconds
        time = Date().timeIntervalSinceReferenceDate //- startTime
        
        // Calculate minutes
        let minutes = UInt8(time / 60.0)
        time -= (TimeInterval(minutes) * 60)
        
        // Calculate seconds
        let seconds = UInt8(time)
        time -= TimeInterval(seconds)
        
        // Calculate milliseconds
        let milliseconds = UInt8(time * 100)
        
        // Format time vars with leading zero
        let strMinutes = String(format: "%02d", minutes)
        let strSeconds = String(format: "%02d", seconds)
        let strMilliseconds = String(format: "%02d", milliseconds)
        
        // Add time vars to relevant labels
        labelMinute.text = strMinutes
        labelSecond.text = strSeconds
 
        labelMillisecond.text = strMilliseconds
 */
        
       self.labelMillisecond.text = "\(Date())"
      //self.labelMillisecond.text = "\(Date(milliseconds: Date().millisecondsSince1970))"
        
        
     //   let secondsNew = calendar.component(.second, from: expirationDate)
        
          self.labelSecond.text = "...\(sendMin) vs \(calendar.component(.minute,from: Date()))..."
        
        if(calendar.component(.minute, from: Date()) == sendMin){
            self.labelMinute.text = "DING"
        }
    }
    
    
    func start() {
        
        startTime = Date().timeIntervalSinceReferenceDate - elapsed
        timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        
        // Set Start/Stop button to true
        status = true
        
        
        components.setValue(2, for: .second)
      //  let expirationDate = Calendar.current.date(byAdding: components, to: date)
    }
    
    @IBAction func sendMessageToWatch(_ sender: Any) {
        //send messages to watch
        session.sendMessage(["a":sendMin], replyHandler: nil, errorHandler: nil)
        //  session.sendMessage(["a":"hello"], replyHandler: nil, errorHandler: nil)
    }
        
    var lastMessage: CFAbsoluteTime = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if (WCSession.isSupported()) {
            self.session = WCSession.default
            self.session.delegate = self
            self.session.activate()
        }
        
        //instantiate datePicker
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .time

        datePicker?.addTarget(self, action: #selector(ViewController.dateChanged(datePicker:)), for: .valueChanged)
        
        inputTimeField.inputView = datePicker
        
        let toolBar = UIToolbar().ToolbarPiker(mySelect: #selector(ViewController.dismissPicker))
        
        inputTimeField.inputAccessoryView = toolBar
        
  /*      let tapGesture = UITapGestureRecognizer(target: self, action: #selector(ViewController.viewTapped(gestureRecognizer:)))
        
        view.addGestureRecognizer(tapGesture)*/
    }
    
    
    @objc func dismissPicker() {
        view.endEditing(true)
    }
    /*
    @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer){
        view.endEditing(true)
    }*/
    
    //this is the datepicker changing dates
    @objc func dateChanged(datePicker: UIDatePicker){
        
       // let formatter = DateFormatter()
        //formatter.dateFormat = "MM/dd/yyyy"
      //  inputTimeField.text = formatter.string(from: datePicker.date)
        
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        inputTimeField.text = formatter.string(from: datePicker.date)
        sendString = formatter.string(from: datePicker.date)
        
        //break up the datepicker data
        let datePickerData = datePicker.date
        let components = Calendar.current.dateComponents([.hour, .minute], from: datePickerData)
         sendHour = components.hour!
         sendMin = components.minute!
        
        //view.endEditing(true)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        //receieve messages from watch
        self.messageLabel.text = message["b"]! as? String
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
            
    }
        
    func sessionDidBecomeInactive(_ session: WCSession) {
            
    }
        
    func sessionDidDeactivate(_ session: WCSession) {
            
    }
    
        
    func sendWatchMessage() {
            let currentTime = CFAbsoluteTimeGetCurrent()
            
            // if less than half a second has passed, bail out
            if lastMessage + 0.5 > currentTime {
                return
            }
            
            // send a message to the watch if it's reachable
            if (WCSession.default.isReachable) {
                // this is a meaningless message, but it's enough for our purposes
                let message = ["Message": "Hello"]
                WCSession.default.sendMessage(message, replyHandler: nil)
            }
            
            // update our rate limiting property
            lastMessage = CFAbsoluteTimeGetCurrent()
        }
}

