//
//  ViewController.swift
//  MUSC-Anesthesia
//
//  Created by Nicolas Threatt on 6/19/18.
//  Copyright © 2018 Riggs Lab. All rights reserved.
//

import UIKit
import WatchConnectivity


//class ViewController: UIViewController {
class ViewController: UIViewController, WCSessionDelegate {
    var session: WCSession!
    
    @IBOutlet weak var messageLabel: UILabel!
    
    @IBAction func sendMessageToWatch(_ sender: Any) {
        //send messages to watch
        session.sendMessage(["a":"hello"], replyHandler: nil, errorHandler: nil)
    }
        
    var lastMessage: CFAbsoluteTime = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if (WCSession.isSupported()) {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        //receieve messages from watch
        self.messageLabel.text=message["b"]! as? String
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
            
    }
        
    func sessionDidBecomeInactive(_ session: WCSession) {
            
    }
        
    func sessionDidDeactivate(_ session: WCSession) {
            
    }
    
        
    func sendWatchMessage() {
            let currentTime = CFAbsoluteTimeGetCurrent()
            
            // if less than half a second has passed, bail out
            if lastMessage + 0.5 > currentTime {
                return
            }
            
            // send a message to the watch if it's reachable
            if (WCSession.default.isReachable) {
                // this is a meaningless message, but it's enough for our purposes
                let message = ["Message": "Hello"]
                WCSession.default.sendMessage(message, replyHandler: nil)
            }
            
            // update our rate limiting property
            lastMessage = CFAbsoluteTimeGetCurrent()
        }
}

